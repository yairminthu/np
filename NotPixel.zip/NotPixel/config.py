# put yours
API_ID = 22524467
API_HASH = "748d3dd5fcab9ba065a620c0067a04b3"

# =============[upgrades]================
# default is 5 level you can change it your self
PAINT_REWARD_MAX = 5 # max is 7
ENERGY_LIMIT_MAX = 5 # max is 6
RE_CHARGE_SPEED_MAX = 5 # max is 11

# ================[proxy]================
USE_PROXY = False # or put True if you want use it
PROXIES = {
    "http":"socks5://102.212.90.109",
    "https":"socks5://216.173.72.30", # if you using socks4 or http only replace it with "socks5"
}
